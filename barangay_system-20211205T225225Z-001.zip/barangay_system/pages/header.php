  <?php

   echo  '<header class="">
   <nav class="navbar">
  <div class="">
 <ul class="nav navbar-nav">
        <li>
       <a href="../dashboard/dashboard.php">
           <i class="fa fa-dashboard"></i> <span>Dashboard</span>
           </a>
          </li>
          <li>
          <a href="../officials/officials.php">
              <i class="fa fa-user"></i> <span>Barangay Officials</span>
                </a> 
            </li>
       
           <li>
         <a href="../resident/resident.php">
            <i class="fa fa-users"></i> <span>Resident</span>
        </a>
                      </li>
                
            <li>
             <a href="../clearance/clearance.php">
            <i class="fa fa-file"></i> <span>Clearance</span>
                   </a> 
                       </li>
               <li>
             <a href="../../logout.php">
             <i class="btn btn-default btn-flat"></i><span>Sign out</span>
              </a>
           
             </li>
                       
             
               </ul>
                </div>

            </nav>
        </header>'; ?>
     
                         
                            </div>
                        </div>
                    </div>
                    
                </div>
              </div>
              </form>
            </div>


            
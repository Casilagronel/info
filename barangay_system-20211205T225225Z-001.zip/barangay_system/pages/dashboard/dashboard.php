<!DOCTYPE html>
<html>

    <?php
    session_start();
    if(!isset($_SESSION['role']))
    {
        header("Location: ../../login.php"); 
    }
    else
    {
    ob_start();
    include('../head_css.php'); ?>
    <body class="skin-black">
        <?php 
        
        include "../connection.php";
        ?>
        <?php include('../header.php'); ?>
        <div class="">
          
      <aside class="">
            
     <section class="content-header">
    <center>  <h1>
          Dashboard
                 </h1>
         </center>
     </section>
    
          <section class="content">
        <div class="row">
            <!-- left column -->
               <div class="box">
            
       <div class="box-body table-responsive">
   
          <div class="row">                     
                               
         <div class="col-md-6 col-sm-12 col-xs-12">                     
         <div class="panel panel-default">
          <div class="panel-heading">
           Resident by Educational Attainment
             </div>
             <div class="panel-body">
            <div id="morris-donut-chart"></div>
             </div>
             </div>            
             </div>
           <div class="col-md-6 col-sm-12 col-xs-12">                     
            <div class="panel panel-default">
             <div class="panel-heading">
                Resident by Gender
               </div>
         <div class="panel-body">
          <div id="morris-donut-chart02"></div>
                 </div>
                  </div>            
                 </div>
                             
                                             
                   </div> 
                             </div><!-- /.box-body -->
                           </div><!-- /.box -->

                    </div>   <!-- /.row -->
                </section><!-- /.content -->

            </aside>
        </div>
        
        
        <?php }
        include "../footer.php";

        include "donut-chart.php";  
        
        ?>

<script type="text/javascript">
    $(function() {
        $("#table").dataTable({
           "aoColumnDefs": [ { "bSortable": false, "aTargets": [ 0,5 ] } ],"aaSorting": []
        });
    });
</script>


    </body>
</html>
  <?php
 echo  '<header class="header">
  <a href="#" class="logo">
  <!-- Add the class icon to your logo image or logo icon to add the margining -->
    Barangay Information System
 </a>
<!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-inverse" >
    <div class="container-fluid">
   
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
     <span class="sr-only">Toggle navigation</span>
     <span class="icon-bar"></span>
     <span class="icon-bar"></span>
     <span class="icon-bar"></span>
     </button>
     </div>
     <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
     <div class="navbar-header">
     <button type="button" class="navbar-dark bg-transparent" data-toggle="collapse" data-target=".navbar-collapse">
     <span class="icon-bar"></span>
     <span class="icon-bar"></span>
     <span class="icon-bar"></span>
    </button>
      <div class="navbar-collapse">
       <ul class="nav navbar-nav">
        <li>
         <a href="../dashboard/dashboard.php">
    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
       </a>
       </li>
       <li>
    <a href="../officials/officials.php">
    <i class="fa fa-user"></i> <span>Barangay Officials</span>
    </a> 
     </li>
     <li>
    <a href="../resident/resident.php">
      <i class="fa fa-users"></i> <span>Resident</span>
       </a>
          </li>
            <li>
      <a href="../clearance/clearance.php">
        <i class="fa fa-file"></i> <span>Clearance</span>
     </a> 
    </li>
   <!-- User Account: style can be found in dropdown.less -->
   <li class="dropdown user user-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
       <i class="glyphicon glyphicon-user"></i><span>'.$_SESSION['role'].'<i class="caret"></i></span>
   </a>
      <ul class="dropdown-menu">
       <!-- User image -->
    <li class="user-header bg-light-blue">
             
      <p>
   '.$_SESSION['role'].'
     </p>
     </li>
   <!-- Menu Body -->
                  
     <!-- Menu Footer-->
     <li class="user-footer">
         <div class="pull-left">
     <a href="#" class="btn btn-default btn-flat" data-toggle="modal" data-target="#editProfileModal">Change Account</a>
            </div>
        <div class="pull-right">
        <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
         </div>
        </li>
        </ul>
       </li>
         </ul>
          </div>
          </nav>
       </header>'; ?>
          <?php
          if($_SESSION['role'] == "Administrator"){
         $user = mysqli_query($con,"SELECT * from tbluser where id = '".$_SESSION['userid']."' ");
         while($row = mysqli_fetch_array($user)){
         echo '
        <div class="form-group">
         <label>Username:</label>
         <input name="txt_username" id="txt_username" class="form-control input-sm" type="text" value="'.$row['username'].'" />
         </div>
            <div class="form-group">
                 <label>Password:</label>
                <input name="txt_password" id="txt_password" class="form-control input-sm" type="password"  value="'.$row['password'].'"/>
                  </div>';
             }    }
           
   else {
          $user = mysqli_query($con,"SELECT * from tblresident where id = '".$_SESSION['userid']."' ");
            while($row = mysqli_fetch_array($user)){
               echo '
              <div class="form-group">
               <label>Username:</label>
               <input name="txt_username" id="txt_username" class="form-control input-sm" type="text" value="'.$row['username'].'" />
                  </div>
                  <div class="form-group">
              <label>Password:</label>
              <input name="txt_password" id="txt_password" class="form-control input-sm" type="password"  value="'.$row['password'].'"/>
                </div>';
               } 
                  }
                   ?>
                       
              </div>
               </div>
               </div>
               
                </div>
              </div>
              </form>
            </div>


          